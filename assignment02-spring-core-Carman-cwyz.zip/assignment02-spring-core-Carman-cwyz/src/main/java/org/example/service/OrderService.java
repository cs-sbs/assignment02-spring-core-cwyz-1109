package org.example.service;

import org.example.model.Order;

public interface OrderService {
    void createOrder(Order order);
    Order getOrder(int id);
} 